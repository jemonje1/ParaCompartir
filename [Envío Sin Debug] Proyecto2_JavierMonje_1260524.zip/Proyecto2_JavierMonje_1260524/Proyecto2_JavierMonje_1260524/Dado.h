#pragma once
#include <iostream>
#include <random>
#include <time.h>
#include <stdlib.h>
//Funcion de dado
class Dado
{
public:
	int tirarDado();
};